const { MongoClient } = require('mongodb');

const MONGODB_URI = 'mongodb+srv://effectmoe:Dhfgmtekd77@cluster0.h1e6k.mongodb.net/accounting-automation?retryWrites=true&w=majority&appName=Cluster0';

async function testMongoDB() {
  let client;
  
  try {
    console.log('🔌 MongoDB接続テスト開始...');
    
    // MongoDB接続
    client = new MongoClient(MONGODB_URI);
    await client.connect();
    console.log('✅ MongoDB接続成功');
    
    const db = client.db('accounting-automation');
    console.log('✅ データベース取得成功');
    
    // FAQコレクションをテスト
    const faqCollection = db.collection('faq');
    console.log('✅ FAQコレクション取得成功');
    
    // 既存ドキュメント数を確認
    const count = await faqCollection.countDocuments();
    console.log(`📊 既存FAQ数: ${count}`);
    
    // テストデータを挿入
    const testData = {
      question: 'テスト質問',
      answer: 'テスト回答',
      sessionId: 'test_session_' + Date.now(),
      createdAt: new Date(),
      savedAt: new Date(),
      category: 'test',
      status: 'active',
      tags: ['test']
    };
    
    console.log('📝 テストデータ挿入中...');
    const result = await faqCollection.insertOne(testData);
    console.log('✅ テストデータ挿入成功');
    console.log('挿入されたID:', result.insertedId);
    
    // 挿入したデータを取得
    const insertedDoc = await faqCollection.findOne({ _id: result.insertedId });
    console.log('✅ データ取得成功');
    console.log('取得したデータ:', {
      _id: insertedDoc._id,
      question: insertedDoc.question,
      answer: insertedDoc.answer,
      category: insertedDoc.category
    });
    
    // テストデータを削除
    await faqCollection.deleteOne({ _id: result.insertedId });
    console.log('✅ テストデータ削除成功');
    
    console.log('🎉 MongoDB FAQ機能テスト完了');
    
  } catch (error) {
    console.error('❌ エラー発生:', error);
    console.error('エラー詳細:', error.message);
    if (error.code) {
      console.error('エラーコード:', error.code);
    }
  } finally {
    if (client) {
      await client.close();
      console.log('🔌 MongoDB接続を閉じました');
    }
  }
}

testMongoDB();