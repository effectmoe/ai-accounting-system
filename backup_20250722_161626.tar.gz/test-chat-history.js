#!/usr/bin/env node

// テスト用スクリプト：チャット履歴APIの動作確認

const BASE_URL = 'http://localhost:3000';

async function testChatHistory() {
  console.log('=== チャット履歴APIテスト開始 ===\n');

  try {
    // 1. 履歴一覧取得（修正されたクエリ）
    console.log('1. 履歴一覧を取得中...');
    const listResponse = await fetch(`${BASE_URL}/api/chat-history/list?category=tax`);
    const listData = await listResponse.json();
    
    if (!listResponse.ok) {
      console.error('エラー:', listData);
      return;
    }
    
    console.log(`✓ 履歴取得成功: ${listData.sessions.length}件のセッション`);
    if (listData.sessions.length > 0) {
      console.log('最新のセッション:', {
        sessionId: listData.sessions[0].sessionId,
        title: listData.sessions[0].title,
        messageCount: listData.sessions[0].messageCount
      });
    }
    
    // 2. 新しいセッション作成
    console.log('\n2. 新しいセッションを作成中...');
    const createResponse = await fetch(`${BASE_URL}/api/chat-history`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        title: 'テストセッション ' + new Date().toLocaleString(),
        userId: null
      })
    });
    
    const createData = await createResponse.json();
    if (!createResponse.ok) {
      console.error('エラー:', createData);
      return;
    }
    
    const sessionId = createData.data.sessionId;
    console.log('✓ セッション作成成功:', sessionId);
    
    // 3. メッセージ追加
    console.log('\n3. メッセージを追加中...');
    const messageResponse = await fetch(`${BASE_URL}/api/chat-history/${sessionId}/messages`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        role: 'user',
        content: 'テストメッセージです'
      })
    });
    
    const messageData = await messageResponse.json();
    if (!messageResponse.ok) {
      console.error('エラー:', messageData);
      return;
    }
    
    console.log('✓ メッセージ追加成功');
    
    // 4. セッション詳細取得
    console.log('\n4. セッション詳細を取得中...');
    const detailResponse = await fetch(`${BASE_URL}/api/chat-history/${sessionId}`);
    const detailData = await detailResponse.json();
    
    if (!detailResponse.ok) {
      console.error('エラー:', detailData);
      return;
    }
    
    console.log('✓ セッション詳細取得成功:', {
      messageCount: detailData.data.messages.length,
      status: detailData.data.status
    });
    
    // 5. FAQ保存テスト
    console.log('\n5. FAQ保存をテスト中...');
    const faqResponse = await fetch(`${BASE_URL}/api/faq/save`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        question: 'テスト質問',
        answer: 'テスト回答',
        sessionId: sessionId,
        timestamp: new Date().toISOString()
      })
    });
    
    const faqData = await faqResponse.json();
    if (!faqResponse.ok) {
      console.error('エラー:', faqData);
    } else {
      console.log('✓ FAQ保存成功:', faqData.id);
    }
    
    console.log('\n=== テスト完了 ===');
    
  } catch (error) {
    console.error('テスト中にエラーが発生:', error);
  }
}

// 実行
testChatHistory();