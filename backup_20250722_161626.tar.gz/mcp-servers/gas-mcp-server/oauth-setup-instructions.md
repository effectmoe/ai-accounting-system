# Google Apps Script MCP - OAuth設定手順

## 重要：手動で行っていただく必要がある作業

### 1. Google Cloud Consoleでの設定

1. [Google Cloud Console](https://console.cloud.google.com) にアクセス
2. プロジェクトを選択または新規作成
3. 左メニューから「APIとサービス」→「有効なAPI」
4. 「APIとサービスを有効化」をクリック
5. 「Google Apps Script API」を検索して有効化

### 2. OAuth認証情報の作成

1. 「APIとサービス」→「認証情報」
2. 「認証情報を作成」→「OAuth クライアント ID」
3. アプリケーションの種類: **「デスクトップアプリ」**
4. 名前: `GAS MCP Client`
5. 作成後、JSONファイルをダウンロード

### 3. oauth-config.jsonの設定

ダウンロードしたJSONファイルを以下の場所にコピー：
```
/Users/tonychustudio/Documents/aam-orchestration/accounting-automation/gas-mcp-server/oauth-config.json
```

### 4. 初回認証の実行

```bash
cd /Users/tonychustudio/Documents/aam-orchestration/accounting-automation/gas-mcp-server
npm start
```

ブラウザが開いたら：
1. Googleアカウントでログイン
2. 権限を許可
3. 認証完了

## 確認事項

認証が成功すると、以下のファイルが作成されます：
- `~/.mcp-gas-auth/tokens.json`

これで設定は完了です！