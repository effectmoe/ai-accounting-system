#!/bin/bash

# Vercel環境変数追加スクリプト

echo "環境変数を追加しています..."

# ANTHROPIC_API_KEY
echo "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" | vercel env add ANTHROPIC_API_KEY production

# OPENAI_API_KEY
echo "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" | vercel env add OPENAI_API_KEY production

# SENTRY_DSN (オプション)
echo "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" | vercel env add SENTRY_DSN production

echo "環境変数の追加が完了しました"