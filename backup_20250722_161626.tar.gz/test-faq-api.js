// FAQ保存APIテスト用スクリプト
const fetch = require('node-fetch');

async function testFaqSaveAPI() {
  console.log('📝 FAQ保存APIテスト開始...');
  
  const baseUrl = 'http://localhost:3000'; // ローカル開発サーバー用
  // const baseUrl = 'https://your-vercel-deployment.vercel.app'; // Vercelデプロイ時は変更
  
  const testData = {
    question: 'テスト質問: 消費税の計算方法は？',
    answer: 'テスト回答: 消費税は売上高に消費税率（10%または8%）を乗じて計算します。',
    sessionId: 'test_session_' + Date.now(),
    timestamp: new Date().toISOString()
  };
  
  try {
    console.log('📤 APIリクエスト送信中...');
    console.log('URL:', `${baseUrl}/api/faq/save`);
    console.log('データ:', testData);
    
    const response = await fetch(`${baseUrl}/api/faq/save`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(testData),
    });
    
    console.log('📥 レスポンス受信:');
    console.log('ステータス:', response.status);
    console.log('ステータステキスト:', response.statusText);
    
    const responseText = await response.text();
    console.log('レスポンス生テキスト:', responseText);
    
    let responseData;
    try {
      responseData = JSON.parse(responseText);
      console.log('📊 レスポンスデータ:', responseData);
    } catch (parseError) {
      console.error('❌ JSONパースエラー:', parseError.message);
      return;
    }
    
    if (response.ok) {
      console.log('✅ FAQ保存APIテスト成功');
      console.log('保存されたID:', responseData.id);
    } else {
      console.error('❌ FAQ保存APIテスト失敗');
      console.error('エラーメッセージ:', responseData.error);
    }
    
  } catch (error) {
    console.error('❌ ネットワークエラー:', error.message);
    console.error('詳細:', error);
  }
}

// メイン実行
if (require.main === module) {
  testFaqSaveAPI();
}

module.exports = { testFaqSaveAPI };