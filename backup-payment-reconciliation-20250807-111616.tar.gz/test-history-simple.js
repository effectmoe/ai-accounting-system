const fetch = require('node-fetch');

async function testHistoryAPI() {
  console.log('🔍 履歴API直接テスト開始\n');
  
  const baseUrl = 'http://localhost:3000';
  
  try {
    // 履歴一覧API呼び出し
    console.log('📡 /api/chat-history/list?category=tax を呼び出し中...');
    
    const response = await fetch(`${baseUrl}/api/chat-history/list?category=tax`);
    
    console.log(`ステータス: ${response.status}`);
    console.log(`Content-Type: ${response.headers.get('content-type')}`);
    
    if (response.ok) {
      const data = await response.json();
      console.log('✅ レスポンス成功:');
      console.log(JSON.stringify(data, null, 2));
    } else {
      const errorText = await response.text();
      console.log('❌ エラーレスポンス:');
      console.log(errorText);
    }
    
  } catch (error) {
    console.error('💥 リクエストエラー:', error.message);
    console.log('\n🚨 ローカルサーバーが起動していない可能性があります');
    console.log('以下のコマンドで開発サーバーを起動してください:');
    console.log('npm run dev');
  }
}

testHistoryAPI();