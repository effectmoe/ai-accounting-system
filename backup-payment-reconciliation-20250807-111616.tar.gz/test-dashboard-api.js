/**
 * Simple test script for dashboard metrics and activity log APIs
 */

const BASE_URL = 'http://localhost:3000';

async function testAPI(endpoint, method = 'GET', body = null) {
  try {
    console.log(`\n🧪 Testing ${method} ${endpoint}`);
    
    const options = {
      method,
      headers: {
        'Content-Type': 'application/json',
      },
    };
    
    if (body) {
      options.body = JSON.stringify(body);
    }
    
    const response = await fetch(`${BASE_URL}${endpoint}`, options);
    const data = await response.json();
    
    if (response.ok) {
      console.log(`✅ Success (${response.status}):`, JSON.stringify(data, null, 2));
    } else {
      console.log(`❌ Error (${response.status}):`, JSON.stringify(data, null, 2));
    }
    
    return { success: response.ok, data };
  } catch (error) {
    console.log(`💥 Network Error:`, error.message);
    return { success: false, error: error.message };
  }
}

async function runTests() {
  console.log('🚀 Starting Dashboard API Tests...\n');
  
  // Test 1: Create a test activity log
  console.log('=== Test 1: Create Activity Log ===');
  await testAPI('/api/activities', 'POST', {
    type: 'customer_created',
    entityType: 'customer',
    description: 'テスト顧客が作成されました - テスト株式会社',
    metadata: { customerName: 'テスト株式会社' },
    severity: 'low'
  });
  
  // Test 2: Get dashboard metrics
  console.log('\n=== Test 2: Get Dashboard Metrics ===');
  await testAPI('/api/dashboard/metrics');
  
  // Test 3: Get activity logs
  console.log('\n=== Test 3: Get Activity Logs ===');
  await testAPI('/api/activities?limit=5');
  
  // Test 4: Create another activity log (invoice created)
  console.log('\n=== Test 4: Create Invoice Activity Log ===');
  await testAPI('/api/activities', 'POST', {
    type: 'invoice_created',
    entityType: 'invoice',
    description: 'テスト請求書が作成されました - テスト株式会社 (¥100,000)',
    metadata: { customerName: 'テスト株式会社', amount: 100000 },
    severity: 'low'
  });
  
  // Test 5: Get updated dashboard metrics
  console.log('\n=== Test 5: Get Updated Dashboard Metrics ===');
  await testAPI('/api/dashboard/metrics');
  
  console.log('\n🎉 All tests completed!');
}

// Check if running as script
if (require.main === module) {
  runTests().catch(console.error);
}

module.exports = { testAPI, runTests };