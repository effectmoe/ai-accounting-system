// APIを直接テスト
const axios = require('axios');

async function testAPI() {
  console.log('🔍 APIテスト開始...\n');
  
  try {
    const response = await axios.get('http://localhost:3000/api/dashboard/metrics');
    console.log('ステータス:', response.status);
    console.log('\n✅ JSONデータ:');
    console.log('- 総収益:', response.data.totalRevenue);
    console.log('- 処理済み書類:', response.data.processedDocuments);
    console.log('- アクティブ顧客:', response.data.activeCustomers);
  } catch (error) {
    console.error('❌ エラー:', error.response?.status || error.message);
    console.error('詳細:', error.response?.data || error.message);
  }
}

testAPI();