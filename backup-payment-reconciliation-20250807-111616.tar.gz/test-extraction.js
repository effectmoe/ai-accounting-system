#!/usr/bin/env node

const url = 'https://abposter.jp/basic/tokusho.html';

async function testExtractionAPI() {
  console.log('🧪 Testing API extraction endpoint...');
  
  try {
    const response = await fetch('http://localhost:3000/api/extract-company-info', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ url })
    });
    
    const result = await response.json();
    
    console.log('\n📊 API Response:');
    console.log(JSON.stringify(result, null, 2));
    
    if (result.success) {
      console.log('\n✅ Extraction Results:');
      console.log(`Company Name: ${result.companyName || 'NOT FOUND'}`);
      console.log(`Company Name Kana: ${result.companyNameKana || 'NOT FOUND'}`);
      console.log(`Postal Code: ${result.postalCode || 'NOT FOUND'}`);
      console.log(`Prefecture: ${result.prefecture || 'NOT FOUND'}`);
      console.log(`City: ${result.city || 'NOT FOUND'}`);
      console.log(`Address1: ${result.address1 || 'NOT FOUND'}`);
      console.log(`Address2: ${result.address2 || 'NOT FOUND'}`);
      console.log(`Phone: ${result.phone || 'NOT FOUND'}`);
      console.log(`Fax: ${result.fax || 'NOT FOUND'}`);
      console.log(`Email: ${result.email || 'NOT FOUND'}`);
      console.log(`Website: ${result.website || 'NOT FOUND'}`);
    } else {
      console.log('❌ Extraction failed:', result.error);
    }
    
  } catch (error) {
    console.error('❌ API test failed:', error.message);
  }
}

testExtractionAPI().catch(console.error);