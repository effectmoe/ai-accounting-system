const { MongoClient } = require('mongodb');
require('dotenv').config({ path: '.env.local' });

async function testConnection() {
  console.log('Testing MongoDB connection...');
  console.log('MONGODB_URI:', process.env.MONGODB_URI ? '✅ Set' : '❌ Not Set');
  console.log('MONGODB_DB_NAME:', process.env.MONGODB_DB_NAME || 'Not Set');

  if (!process.env.MONGODB_URI) {
    console.error('❌ MONGODB_URI is not set in .env.local');
    return;
  }

  const client = new MongoClient(process.env.MONGODB_URI, {
    serverSelectionTimeoutMS: 5000,
  });

  try {
    await client.connect();
    console.log('✅ Successfully connected to MongoDB');

    const db = client.db(process.env.MONGODB_DB_NAME || 'accounting');
    console.log('✅ Database:', db.databaseName);

    // Test collections
    const collections = await db.listCollections().toArray();
    console.log('✅ Collections:', collections.map(c => c.name));

    // Test insert
    const testCollection = db.collection('test_connection');
    const result = await testCollection.insertOne({ 
      test: true, 
      timestamp: new Date() 
    });
    console.log('✅ Test insert successful:', result.insertedId);

    // Cleanup
    await testCollection.deleteOne({ _id: result.insertedId });
    console.log('✅ Test cleanup successful');

  } catch (error) {
    console.error('❌ Connection error:', error.message);
    console.error('Error details:', error);
  } finally {
    await client.close();
  }
}

testConnection();