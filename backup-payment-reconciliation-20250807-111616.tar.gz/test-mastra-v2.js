const axios = require('axios');

async function testMastraV2() {
  console.log('🧪 Mastra V2 本物のAIエージェントテスト\n');
  
  try {
    // 1. システム情報確認
    console.log('1️⃣ システム情報');
    const infoResponse = await axios.get('http://localhost:3000/api/mastra/v2/chat');
    console.log('バージョン:', infoResponse.data.version);
    console.log('モデル:', infoResponse.data.model);
    console.log('ツール:', infoResponse.data.tools.join(', '));
    
    // 2. 自然言語で税計算
    console.log('\n2️⃣ AIに自然言語で税計算を依頼');
    console.log('質問: "売上高200万円の場合、消費税はいくらになりますか？"');
    
    const taxResponse = await axios.post('http://localhost:3000/api/mastra/v2/chat', {
      message: '売上高200万円の場合、消費税はいくらになりますか？'
    });
    
    console.log('\n応答:', taxResponse.data.response);
    if (taxResponse.data.toolsUsed.length > 0) {
      console.log('使用ツール:', taxResponse.data.toolsUsed[0].tool);
      console.log('計算結果:', JSON.stringify(taxResponse.data.toolsUsed[0].result.summary, null, 2));
    }
    
  } catch (error) {
    console.error('❌ エラー:', error.response?.data || error.message);
  }
}

testMastraV2();