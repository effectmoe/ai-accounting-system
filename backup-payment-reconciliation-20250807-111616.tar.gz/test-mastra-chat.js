const axios = require('axios');

async function testMastraChat() {
  console.log('🧪 本物のMastraエージェントテスト\n');
  
  try {
    // 1. 利用可能なエージェント確認
    console.log('1️⃣ 利用可能なエージェント一覧');
    const agentsResponse = await axios.get('http://localhost:3000/api/mastra/chat');
    console.log('エージェント数:', agentsResponse.data.totalAgents);
    console.log('エージェント:', agentsResponse.data.agents.map(a => a.id).join(', '));
    
    // 2. 自然言語で税計算を依頼
    console.log('\n2️⃣ 自然言語で消費税計算を依頼');
    const taxResponse = await axios.post('http://localhost:3000/api/mastra/chat', {
      agent: 'accountingAgent',
      message: '売上100万円に対する消費税を計算してください。税率は10%です。'
    });
    
    console.log('エージェント応答:');
    console.log(taxResponse.data.response);
    
    // 3. 仕訳作成を依頼
    console.log('\n3️⃣ 自然言語で仕訳作成を依頼');
    const journalResponse = await axios.post('http://localhost:3000/api/mastra/chat', {
      agent: 'accountingAgent',
      message: '商品を50万円で販売しました。現金で受け取りました。この取引の仕訳を作成してください。'
    });
    
    console.log('エージェント応答:');
    console.log(journalResponse.data.response);
    
  } catch (error) {
    console.error('❌ エラー:', error.response?.data || error.message);
  }
}

testMastraChat();