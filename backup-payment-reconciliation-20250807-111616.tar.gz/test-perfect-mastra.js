const axios = require('axios');

async function testPerfectMastra() {
  console.log('🎯 Perfect Mastra テスト\n');
  
  try {
    // 1. システム情報確認
    console.log('1️⃣ システム情報');
    const infoResponse = await axios.get('http://localhost:3000/api/mastra/perfect');
    console.log('Framework:', infoResponse.data.framework);
    console.log('Status:', infoResponse.data.status);
    console.log('Agents:', JSON.stringify(infoResponse.data.agents, null, 2));
    
    // 2. 税計算テスト
    console.log('\n2️⃣ 税計算テスト');
    console.log('メッセージ: "300万円の売上に対する消費税を計算してください"');
    
    const taxResponse = await axios.post('http://localhost:3000/api/mastra/perfect', {
      message: '300万円の売上に対する消費税を計算してください'
    });
    
    console.log('\n成功:', taxResponse.data.success);
    console.log('応答:', taxResponse.data.response);
    
    if (taxResponse.data.toolCalls && taxResponse.data.toolCalls.length > 0) {
      console.log('\nツール実行:');
      console.log(JSON.stringify(taxResponse.data.toolCalls, null, 2));
    }
    
    // 3. 仕訳作成テスト
    console.log('\n3️⃣ 仕訳作成テスト');
    console.log('メッセージ: "商品を100万円で現金販売しました。仕訳を作成してください"');
    
    const journalResponse = await axios.post('http://localhost:3000/api/mastra/perfect', {
      message: '商品を100万円で現金販売しました。仕訳を作成してください'
    });
    
    console.log('\n成功:', journalResponse.data.success);
    console.log('応答:', journalResponse.data.response);
    
  } catch (error) {
    console.error('❌ エラー:', error.response?.data || error.message);
  }
}

testPerfectMastra();