// ダッシュボードAPIのテスト
const axios = require('axios');

async function testDashboard() {
  try {
    console.log('🔍 Dashboard APIをテスト中...');
    
    const response = await axios.get('http://localhost:3001/api/dashboard/metrics');
    
    console.log('✅ APIレスポンス成功!');
    console.log('ステータス:', response.status);
    console.log('\nデータ:');
    console.log(JSON.stringify(response.data, null, 2));
    
  } catch (error) {
    console.error('❌ エラー発生:');
    if (error.response) {
      console.error('ステータス:', error.response.status);
      console.error('データ:', error.response.data);
    } else {
      console.error('メッセージ:', error.message);
    }
  }
}

// 3秒待ってからテスト（サーバー起動を待つ）
setTimeout(() => {
  testDashboard();
}, 3000);