// Simple Mastra configuration without complex features
import { Mastra } from 'mastra';

// Create simple Mastra instance
export const mastra = new Mastra({
  // No complex configuration
});

// Export for Mastra Cloud
export default mastra;