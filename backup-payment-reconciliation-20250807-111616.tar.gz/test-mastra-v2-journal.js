const axios = require('axios');

async function testJournalEntry() {
  console.log('🧪 Mastra V2 仕訳作成テスト\n');
  
  try {
    console.log('1️⃣ 自然言語で仕訳作成を依頼');
    console.log('質問: "商品を50万円で販売しました。現金で受け取りました。この取引の仕訳を作成してください。"\n');
    
    const response = await axios.post('http://localhost:3000/api/mastra/v2/chat', {
      message: '商品を50万円で販売しました。現金で受け取りました。この取引の仕訳を作成してください。'
    });
    
    console.log('応答:', response.data.response);
    
    if (response.data.toolsUsed.length > 0) {
      console.log('\n使用ツール:', response.data.toolsUsed[0].tool);
      console.log('作成された仕訳:');
      const result = response.data.toolsUsed[0].result;
      console.log(JSON.stringify(result, null, 2));
    }
    
  } catch (error) {
    console.error('❌ エラー:', error.response?.data || error.message);
  }
}

testJournalEntry();