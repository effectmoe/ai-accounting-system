const axios = require('axios');

async function testWorkingAPI() {
  console.log('🎯 動作するAPI テスト\n');
  
  try {
    // 1. APIステータス確認
    console.log('1️⃣ APIステータス確認');
    const statusResponse = await axios.get('http://localhost:3000/api/mastra/working');
    console.log('ステータス:', statusResponse.data);
    
    // 2. 税計算テスト
    console.log('\n2️⃣ 消費税計算テスト');
    const taxResponse = await axios.post('http://localhost:3000/api/mastra/working', {
      message: '100万円の売上に対する消費税を計算してください'
    });
    
    console.log('\n応答:', taxResponse.data.response);
    if (taxResponse.data.toolCalls && taxResponse.data.toolCalls.length > 0) {
      console.log('\nツール実行結果:');
      console.log(JSON.stringify(taxResponse.data.toolCalls[0].result, null, 2));
    }
    
  } catch (error) {
    console.error('❌ エラー:', error.response?.data || error.message);
  }
}

testWorkingAPI();