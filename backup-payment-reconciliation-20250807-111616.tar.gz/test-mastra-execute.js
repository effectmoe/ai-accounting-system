const axios = require('axios');

async function testMastraExecute() {
  console.log('🤖 Mastra Agent Execute テスト\n');
  
  try {
    // 1. 利用可能なエージェント確認
    console.log('1️⃣ エージェント一覧');
    const agentsResponse = await axios.get('http://localhost:3000/api/mastra/chat');
    console.log('エージェント数:', agentsResponse.data.totalAgents);
    console.log('エージェント:', agentsResponse.data.agents.map(a => a.id).join(', '));
    
    // 2. 会計エージェントで税計算
    console.log('\n2️⃣ 会計エージェントで税計算');
    const taxResponse = await axios.post('http://localhost:3000/api/mastra/chat', {
      agent: 'accountingAgent',
      message: '500万円の売上に対する消費税を計算してください'
    });
    
    console.log('\n成功:', taxResponse.data.success);
    if (taxResponse.data.response) {
      console.log('応答:', taxResponse.data.response);
    }
    
  } catch (error) {
    console.error('\n❌ エラー:', error.response?.data || error.message);
    if (error.response?.data?.details) {
      console.error('詳細:', JSON.stringify(error.response.data.details, null, 2));
    }
  }
}

testMastraExecute();