#!/usr/bin/env node

const url = 'https://abposter.jp/basic/tokusho.html';

async function testExtractCompany() {
  console.log('🧪 Testing extract-company-info API...');
  console.log(`📍 Testing URL: ${url}`);
  
  try {
    // Test the actual API endpoint
    const response = await fetch('http://localhost:3002/api/extract-company-info', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ url })
    });

    console.log(`📊 HTTP Status: ${response.status}`);
    console.log(`📊 Response Headers:`, Object.fromEntries(response.headers.entries()));

    const data = await response.json();
    
    console.log('\n✅ API Response:');
    console.log(JSON.stringify(data, null, 2));
    
    // Analyze response
    console.log('\n🔍 Response Analysis:');
    console.log(`Success: ${data.success || 'undefined'}`);
    console.log(`Company Name: ${data.companyName || 'Not found'}`);
    console.log(`Company Kana: ${data.companyNameKana || 'Not found'}`);
    console.log(`Address: ${data.address || 'Not found'}`);  
    console.log(`Postal Code: ${data.postalCode || 'Not found'}`);
    console.log(`Prefecture: ${data.prefecture || 'Not found'}`);
    console.log(`City: ${data.city || 'Not found'}`);
    console.log(`Address1: ${data.address1 || 'Not found'}`);
    console.log(`Address2: ${data.address2 || 'Not found'}`);
    console.log(`Phone: ${data.phone || 'Not found'}`);
    console.log(`FAX: ${data.fax || 'Not found'}`);
    console.log(`Email: ${data.email || 'Not found'}`);
    console.log(`Website: ${data.website || 'Not found'}`);
    
    // Check for issues
    console.log('\n🚨 Issues Found:');
    if (data.address && data.address.includes('.css">')) {
      console.log('❌ Address contains CSS reference - regex parsing issue');
    }
    
    if (!data.phone && !data.fax && !data.email) {
      console.log('❌ No contact information found');
    }
    
    if (!data.prefecture || !data.city || !data.address1) {
      console.log('❌ Address parsing incomplete');
    }
    
  } catch (error) {
    console.error('❌ Error testing API:', error.message);
  }
}

async function testDirectWebFetch() {
  console.log('\n🌐 Testing direct web fetch...');
  
  try {
    const response = await fetch(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
      }
    });
    
    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    }
    
    const html = await response.text();
    console.log(`📄 HTML length: ${html.length} characters`);
    
    // Check for key elements
    console.log('\n🔍 HTML Content Analysis:');
    
    // Company name from title
    const titleMatch = html.match(/<title>([^<]+)<\/title>/i);
    console.log(`Title: ${titleMatch ? titleMatch[1] : 'Not found'}`);
    
    // Look for postal code
    const postalMatch = html.match(/〒?(\d{3})-?(\d{4})/);
    console.log(`Postal Code: ${postalMatch ? `${postalMatch[1]}-${postalMatch[2]}` : 'Not found'}`);
    
    // Look for phone/fax
    const phoneMatch = html.match(/TEL[：:]?\s*([\d\-\(\)\s\/]+)/i);
    console.log(`Phone/FAX: ${phoneMatch ? phoneMatch[1] : 'Not found'}`);
    
    // Look for email
    const emailMatch = html.match(/[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/);
    console.log(`Email: ${emailMatch ? emailMatch[0] : 'Not found'}`);
    
    // Check for special characters that might break parsing
    const hasSpecialChars = html.includes('2402230216.css">');
    console.log(`Contains problematic CSS reference: ${hasSpecialChars}`);
    
  } catch (error) {
    console.error('❌ Error fetching HTML directly:', error.message);
  }
}

async function main() {
  console.log('🚀 Starting extract-company-info API Debug Test\n');
  
  await testExtractCompany();
  await testDirectWebFetch();
  
  console.log('\n✅ Debug test completed');
}

main().catch(console.error);