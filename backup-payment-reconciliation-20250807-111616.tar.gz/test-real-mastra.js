const axios = require('axios');

async function testRealMastra() {
  console.log('🎯 本物のMastra APIテスト\n');
  
  try {
    // 1. APIステータス確認
    console.log('1️⃣ APIステータス確認');
    const statusResponse = await axios.get('http://localhost:3000/api/mastra/real');
    console.log('ステータス:', statusResponse.data);
    
    // 2. 税計算テスト
    console.log('\n2️⃣ 消費税計算テスト');
    const taxResponse = await axios.post('http://localhost:3000/api/mastra/real', {
      message: '100万円の売上に対する消費税を計算してください'
    });
    
    console.log('\n応答:', taxResponse.data.response);
    if (taxResponse.data.toolCalls && taxResponse.data.toolCalls.length > 0) {
      console.log('ツール使用:', JSON.stringify(taxResponse.data.toolCalls, null, 2));
    }
    
  } catch (error) {
    console.error('❌ エラー:', error.response?.data || error.message);
  }
}

testRealMastra();