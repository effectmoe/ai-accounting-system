// Import the mastra instance from src/mastra/config.ts
module.exports = require('./src/mastra/config').default;