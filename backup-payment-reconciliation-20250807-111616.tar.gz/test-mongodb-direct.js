#!/usr/bin/env node

// MongoDB接続の直接テスト
const { MongoClient } = require('mongodb');
const dotenv = require('dotenv');
const path = require('path');

// 環境変数をクリア
delete process.env.MONGODB_URI;

// .env.local を読み込み
dotenv.config({ path: path.join(__dirname, '.env.local') });

// MongoDB Atlas URIが存在しない場合のフォールバック
const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/accounting-automation';

async function testMongoDBConnection() {
  console.log('=== MongoDB Direct Connection Test ===');
  console.log('MONGODB_URI from env:', MONGODB_URI ? 'Set' : 'Not set');
  console.log('MONGODB_URI value:', MONGODB_URI);
  
  if (!MONGODB_URI) {
    console.error('MONGODB_URI is not set in environment variables');
    process.exit(1);
  }

  let client = null;
  
  try {
    console.log('Attempting to connect to MongoDB...');
    client = new MongoClient(MONGODB_URI);
    await client.connect();
    
    console.log('✓ Successfully connected to MongoDB');
    
    const db = client.db('accounting-automation');
    const collections = await db.listCollections().toArray();
    
    console.log('Available collections:', collections.map(c => c.name));
    
    // chat_sessionsコレクションの存在確認
    const chatSessions = db.collection('chat_sessions');
    const sessionCount = await chatSessions.countDocuments();
    console.log('Number of chat sessions:', sessionCount);
    
    // サンプルクエリの実行
    console.log('\\nTesting query...');
    const query = {
      $and: [
        {
          $or: [
            { status: { $ne: 'deleted' } },
            { status: { $exists: false } }
          ]
        },
        {
          $or: [
            { category: 'tax' },
            { category: { $exists: false } },
            { 'specialization.primaryDomain': '税務' }
          ]
        }
      ]
    };
    
    console.log('Query:', JSON.stringify(query, null, 2));
    
    try {
      const results = await chatSessions.find(query).limit(5).toArray();
      console.log('Query results:', results.length, 'documents found');
      
      if (results.length > 0) {
        console.log('Sample result:', {
          _id: results[0]._id,
          sessionId: results[0].sessionId,
          title: results[0].title,
          category: results[0].category,
          status: results[0].status
        });
      }
    } catch (queryError) {
      console.error('❌ Query execution error:', queryError);
      console.error('Query error details:', queryError.message);
      
      // よりシンプルなクエリでテスト
      console.log('\\nTesting simpler query...');
      const simpleQuery = { status: { $ne: 'deleted' } };
      console.log('Simple query:', JSON.stringify(simpleQuery, null, 2));
      
      try {
        const simpleResults = await chatSessions.find(simpleQuery).limit(5).toArray();
        console.log('Simple query results:', simpleResults.length, 'documents found');
      } catch (simpleError) {
        console.error('❌ Simple query also failed:', simpleError);
      }
    }
    
    console.log('\\n✓ MongoDB connection test completed successfully');
    
  } catch (error) {
    console.error('❌ MongoDB connection error:', error);
    console.error('Error details:', error.message);
    process.exit(1);
    
  } finally {
    if (client) {
      await client.close();
      console.log('MongoDB connection closed');
    }
  }
}

// 実行
testMongoDBConnection();