// TypeScript configuration for Mastra
import { mastra } from './src/mastra/simple-config';

// Export the mastra instance for Mastra Cloud
export default mastra;