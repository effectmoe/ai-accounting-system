// ナレッジAPIのテスト
async function testKnowledgeAPI() {
  try {
    // 検索APIのテスト
    const response = await fetch('http://localhost:3001/api/knowledge?action=search&q=インボイス制度');
    const data = await response.json();
    console.log('Search API Response:', data);
  } catch (error) {
    console.log('API is not ready yet. MongoDB connection required.');
    console.log('Error:', error.message);
  }
}

testKnowledgeAPI();
