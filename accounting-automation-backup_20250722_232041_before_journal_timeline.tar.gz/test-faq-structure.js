const baseUrl = 'http://localhost:3001';

async function testFaqApi() {
  console.log('=== FAQ構造化機能テスト開始 ===\n');

  try {
    // 1. FAQ一覧取得（構造化データ含む）
    console.log('1. FAQ一覧を取得（構造化データ含む）...');
    const faqsResponse = await fetch(`${baseUrl}/api/faq?includeStructuredData=true&limit=5`);
    const faqsData = await faqsResponse.json();
    
    console.log(`取得したFAQ数: ${faqsData.faqs?.length || 0}`);
    if (faqsData.faqs && faqsData.faqs.length > 0) {
      const firstFaq = faqsData.faqs[0];
      console.log('\n最初のFAQ:');
      console.log(`- ID: ${firstFaq.id}`);
      console.log(`- 質問: ${firstFaq.question}`);
      console.log(`- カテゴリ: ${firstFaq.category}`);
      console.log(`- 品質スコア: ${firstFaq.qualityScore}`);
      console.log(`- 構造化データ:`, firstFaq.structuredData);
      console.log(`- 品質メトリクス:`, firstFaq.qualityMetrics);
    }

    // 2. 高度な検索テスト
    console.log('\n2. 高度な検索機能をテスト...');
    const searchResponse = await fetch(`${baseUrl}/api/faq/search`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        query: '税',
        categories: ['tax', 'tax-accounting'],
        qualityScoreMin: 80,
        sortBy: 'quality',
        sortOrder: 'desc',
        limit: 3
      })
    });
    const searchData = await searchResponse.json();
    
    console.log(`検索結果数: ${searchData.results?.length || 0}`);
    console.log('集計情報:', searchData.aggregations);

    // 3. 関連FAQ推奨機能テスト
    if (faqsData.faqs && faqsData.faqs.length > 0) {
      console.log('\n3. 関連FAQ推奨機能をテスト...');
      const firstFaqId = faqsData.faqs[0].id;
      
      const recommendResponse = await fetch(`${baseUrl}/api/faq/recommend`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          faqId: firstFaqId,
          limit: 3
        })
      });
      const recommendData = await recommendResponse.json();
      
      console.log(`推奨FAQ数: ${recommendData.recommendations?.length || 0}`);
      if (recommendData.recommendations) {
        recommendData.recommendations.forEach((rec, index) => {
          console.log(`\n推奨 ${index + 1}:`);
          console.log(`- 質問: ${rec.question}`);
          console.log(`- カテゴリ: ${rec.category}`);
          console.log(`- 関連度スコア: ${rec.relevanceScore}`);
        });
      }
    }

    // 4. FAQ作成テスト（構造化データ付き）
    console.log('\n4. 新しいFAQを作成（構造化データ付き）...');
    const createResponse = await fetch(`${baseUrl}/api/faq`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        question: 'インボイス制度における適格請求書の要件は何ですか？',
        answer: 'インボイス制度における適格請求書には、以下の要件が必要です：\n1. 適格請求書発行事業者の氏名又は名称及び登録番号\n2. 取引年月日\n3. 取引内容（軽減税率の対象品目である旨）\n4. 税率ごとに区分して合計した対価の額及び適用税率\n5. 税率ごとに区分した消費税額等\n6. 書類の交付を受ける事業者の氏名又は名称',
        category: 'tax',
        tags: ['インボイス', '適格請求書', '消費税'],
        difficulty: 'intermediate',
        contentType: 'tax',
        isPublished: true
      })
    });
    const createData = await createResponse.json();
    
    if (createData.success) {
      console.log(`FAQ作成成功: ID = ${createData.faqId}`);
      
      // 5. 作成したFAQを更新（品質スコア調整）
      console.log('\n5. FAQの品質スコアを更新...');
      const updateResponse = await fetch(`${baseUrl}/api/faq`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          id: createData.faqId,
          qualityMetrics: {
            accuracy: 95,
            completeness: 90,
            clarity: 92,
            usefulness: 93
          },
          structuredData: {
            contentType: 'tax',
            taxLaw: ['消費税法'],
            applicableBusinessTypes: ['全業種'],
            relatedRegulations: ['インボイス制度']
          },
          searchKeywords: ['インボイス', '適格請求書', '消費税', '登録番号']
        })
      });
      const updateData = await updateResponse.json();
      
      console.log('更新結果:', updateData.success ? '成功' : '失敗');
    }

    console.log('\n=== FAQ構造化機能テスト完了 ===');

  } catch (error) {
    console.error('テスト中にエラーが発生しました:', error);
  }
}

// テスト実行
testFaqApi();