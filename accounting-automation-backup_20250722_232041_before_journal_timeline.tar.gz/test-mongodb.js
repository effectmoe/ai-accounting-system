require('dotenv').config({ path: '.env.local' });
const { MongoClient } = require('mongodb');

const uri = process.env.MONGODB_URI;

async function testConnection() {
  console.log('Testing MongoDB connection...');
  console.log('MONGODB_URI exists:', !!process.env.MONGODB_URI);
  console.log('URI:', uri ? uri.replace(/:[^:@]+@/, ':***@') : 'NOT SET'); // マスクしたURIを表示
  
  if (!uri) {
    console.error('❌ MONGODB_URI is not set in .env.local');
    return;
  }
  
  try {
    const client = new MongoClient(uri);
    await client.connect();
    console.log('✅ Connected successfully to MongoDB Atlas');
    
    const db = client.db('accounting');
    const collections = await db.listCollections().toArray();
    console.log('\nCollections found:', collections.map(c => c.name));
    
    // ocr_resultsコレクションのデータを確認
    const ocrResults = await db.collection('ocr_results').find({}).limit(5).toArray();
    console.log('\nocr_results count:', await db.collection('ocr_results').countDocuments());
    console.log('Sample ocr_results:', ocrResults.length);
    if (ocrResults.length > 0) {
      console.log('First ocr_result fields:', Object.keys(ocrResults[0]));
    }
    
    // documentsコレクションのデータを確認
    const documents = await db.collection('documents').find({}).limit(5).toArray();
    console.log('\ndocuments count:', await db.collection('documents').countDocuments());
    console.log('Sample documents:', documents.length);
    if (documents.length > 0) {
      console.log('First document fields:', Object.keys(documents[0]));
    }
    
    await client.close();
  } catch (error) {
    console.error('❌ Connection failed:', error.message);
  }
}

testConnection();