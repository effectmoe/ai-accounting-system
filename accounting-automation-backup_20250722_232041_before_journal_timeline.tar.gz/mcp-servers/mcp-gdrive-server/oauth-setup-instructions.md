# Google Drive MCP - OAuth設定手順

## 重要：手動で行っていただく必要がある作業

### 1. Google Cloud Consoleでの設定

1. [Google Cloud Console](https://console.cloud.google.com) にアクセス
2. 同じプロジェクトを使用（GAS MCPと同じでOK）
3. 追加で以下のAPIを有効化：
   - Google Drive API
   - Google Sheets API
   - Google Docs API

### 2. OAuth同意画面の設定

1. 「APIとサービス」→「OAuth同意画面」
2. スコープを追加：
   - `https://www.googleapis.com/auth/drive.readonly`
   - `https://www.googleapis.com/auth/spreadsheets`

### 3. OAuth認証情報の作成

1. 「APIとサービス」→「認証情報」
2. 「認証情報を作成」→「OAuth クライアント ID」
3. アプリケーションの種類: **「デスクトップアプリ」**
4. 名前: `Google Drive MCP Client`
5. 作成後、以下の情報をメモ：
   - クライアントID
   - クライアントシークレット

### 4. 認証情報ファイルの作成

1. ダウンロードしたJSONファイルを以下の場所に保存：
```
/Users/tonychustudio/.config/mcp-gdrive/gcp-oauth.keys.json
```

### 5. .envファイルの更新

`/Users/tonychustudio/Documents/aam-orchestration/accounting-automation/mcp-gdrive-server/.env`を編集：

```env
CLIENT_ID=あなたのクライアントID
CLIENT_SECRET=あなたのクライアントシークレット
GDRIVE_CREDS_DIR=/Users/tonychustudio/.config/mcp-gdrive
```

### 6. 初回認証の実行

```bash
cd /Users/tonychustudio/Documents/aam-orchestration/accounting-automation/mcp-gdrive-server
node ./dist/index.js
```

ブラウザが開いたら：
1. Googleアカウントでログイン
2. 権限を許可
3. 認証完了

## 確認事項

認証が成功すると、トークンファイルが保存されます。