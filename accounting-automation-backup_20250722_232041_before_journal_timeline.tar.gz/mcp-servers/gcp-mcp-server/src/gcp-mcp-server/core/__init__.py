"""Core package for MCP server components."""
