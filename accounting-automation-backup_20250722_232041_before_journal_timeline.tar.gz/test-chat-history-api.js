#!/usr/bin/env node

const { MongoClient } = require('mongodb');
require('dotenv').config({ path: '.env.local' });

const MONGODB_URI = process.env.MONGODB_URI;

async function testChatHistoryAPI() {
  console.log('🔍 チャット履歴機能の調査開始\n');
  
  if (!MONGODB_URI) {
    console.error('❌ MONGODB_URI が設定されていません');
    return;
  }

  console.log(`📊 MongoDB接続先: ${MONGODB_URI.replace(/\/\/([^:]+):([^@]+)@/, '//***:***@')}`);

  let client;
  try {
    // MongoDB接続テスト
    client = new MongoClient(MONGODB_URI);
    await client.connect();
    console.log('✅ MongoDB接続成功\n');

    const db = client.db('accounting-automation');
    
    // コレクション一覧確認
    console.log('📁 利用可能なコレクション:');
    const collections = await db.listCollections().toArray();
    collections.forEach(collection => {
      console.log(`  - ${collection.name}`);
    });
    console.log('');

    // chat_sessionsコレクションの確認
    const sessionsCollection = db.collection('chat_sessions');
    
    // ドキュメント数確認
    const totalCount = await sessionsCollection.countDocuments();
    console.log(`📊 chat_sessionsコレクション総数: ${totalCount}`);

    if (totalCount > 0) {
      // サンプルドキュメント取得
      console.log('\n📄 サンプルドキュメント:');
      const sampleDoc = await sessionsCollection.findOne();
      console.log(JSON.stringify(sampleDoc, null, 2));

      // カテゴリ別統計
      console.log('\n📈 カテゴリ別統計:');
      const categoryStats = await sessionsCollection.aggregate([
        {
          $group: {
            _id: "$category",
            count: { $sum: 1 }
          }
        }
      ]).toArray();
      
      categoryStats.forEach(stat => {
        console.log(`  ${stat._id || 'undefined'}: ${stat.count} セッション`);
      });

      // messageCount別統計
      console.log('\n📈 メッセージ数別統計:');
      const messageStats = await sessionsCollection.aggregate([
        {
          $group: {
            _id: {
              $cond: [
                { $gt: ["$messageCount", 0] },
                "has_messages",
                "no_messages"
              ]
            },
            count: { $sum: 1 }
          }
        }
      ]).toArray();
      
      messageStats.forEach(stat => {
        console.log(`  ${stat._id}: ${stat.count} セッション`);
      });

      // API条件のテスト（category=tax, messageCount > 0）
      console.log('\n🎯 履歴API条件でのフィルタリングテスト:');
      const filteredSessions = await sessionsCollection
        .find({ 
          category: 'tax',
          messageCount: { $gt: 0 }
        })
        .sort({ updatedAt: -1 })
        .limit(20)
        .toArray();

      console.log(`  条件に一致するセッション数: ${filteredSessions.length}`);
      
      if (filteredSessions.length > 0) {
        console.log('  最新セッション:');
        const latestSession = filteredSessions[0];
        console.log(`    ID: ${latestSession._id}`);
        console.log(`    タイトル: ${latestSession.title}`);
        console.log(`    カテゴリ: ${latestSession.category}`);
        console.log(`    メッセージ数: ${latestSession.messageCount}`);
        console.log(`    作成日: ${latestSession.createdAt}`);
        console.log(`    更新日: ${latestSession.updatedAt}`);
      }

      // 全カテゴリのセッション確認
      console.log('\n🔄 全カテゴリでのセッション確認:');
      const allCategories = ['tax', 'accounting', 'journal', 'mixed'];
      
      for (const category of allCategories) {
        const count = await sessionsCollection.countDocuments({ 
          category: category,
          messageCount: { $gt: 0 }
        });
        console.log(`  ${category}: ${count} セッション`);
      }

    } else {
      console.log('⚠️  chat_sessionsコレクションにデータが存在しません');
    }

    // 他のデータベースの確認
    console.log('\n🔍 他のデータベースの確認:');
    const databases = ['accounting'];
    
    for (const dbName of databases) {
      try {
        const testDb = client.db(dbName);
        const testCollections = await testDb.listCollections().toArray();
        console.log(`  ${dbName}データベース:`);
        testCollections.forEach(collection => {
          console.log(`    - ${collection.name}`);
        });
        
        // chat_sessionsがあるかチェック
        const chatSessionsExists = testCollections.some(c => c.name === 'chat_sessions');
        if (chatSessionsExists) {
          const testSessionsCollection = testDb.collection('chat_sessions');
          const testCount = await testSessionsCollection.countDocuments();
          console.log(`    → chat_sessions: ${testCount} ドキュメント`);
        }
      } catch (error) {
        console.log(`    ${dbName}: アクセスエラー - ${error.message}`);
      }
    }

  } catch (error) {
    console.error('❌ エラー:', error);
  } finally {
    if (client) {
      await client.close();
    }
  }
}

// 実行
testChatHistoryAPI()
  .then(() => {
    console.log('\n✅ 調査完了');
    process.exit(0);
  })
  .catch((error) => {
    console.error('💥 予期しないエラー:', error);
    process.exit(1);
  });